class Config {
  static const title = 'Radio Rohozec';
  static const description = 'Radio pro dobrou chuť i náladu';
  static const streamUrl = 'https://radio.mediacp.eu:8074/listen.pls';

  // Social links
  static const instagram = 'https://www.instagram.com/pivorohozec/';
  static const facebook = 'https://www.facebook.com/pivorohozec';
  static const website = 'https://www.pivorohozec.cz/';
  static const email = 'pivorohozec@pivorohozec.cz';

  // Share
  static const shareSubject = 'Radio Rohozec';
  static const shareText = "Poslouchám Rádio Rohozec";

  // Rate Us
  static const appStoreId = '0123456789';

  // Automatically start playing when the app is launched.
  static const autoplay = false;

  // Replace default image with album cover.
  static const showAlbumCover = true;

  // Search album cover on iTunes.
  static const albumCoverFromItunes = true;

  // Long text scrolling.
  static const textScrolling = true;

  // Parse metadata from third-party sources.
  static const metadataUrl = '';
  static const artistTag = 'artist';
  static const trackTag = 'title';
  static const coverTag = 'thumb';
  static const titleTag = '';
  static const titleSeparator = ' - ';
  static const timerPeriod = 2;
}
