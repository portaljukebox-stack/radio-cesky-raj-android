class Language {
  // Greetings
  static const goodMorning = 'Dobré ráno';
  static const goodAfternoon = 'Pěkné odpoledne';
  static const goodEvening = 'Dobrý večer';

  // Sleep Timer
  static const sleepTimer = 'Časovač spánku';
  static const timeLeft = 'Zbývající čas';
  static const startTimer = 'Spustit časovač';
  static const stopTimer = 'Zastavit časovač';

  // About Us
  static const aboutUs = 'O nás';
  static const profile = 'Profil';
  static const description = 'Popis';

  // Sidebar
  static const timer = 'Časovač';
  static const instagram = 'Instagram';
  static const twitter = 'Twitter';
  static const facebook = 'Facebook';
  static const website = 'Webová stránka';
  static const email = 'Email';
  // static const rateUs = 'Ohodnocení aplikace';
  static const privacyPolicy = 'Pravidla ochrany osobních údajů';
  static const privacyPolicyClose = 'Zavřít';
  static const share = 'Sdílet';
}
