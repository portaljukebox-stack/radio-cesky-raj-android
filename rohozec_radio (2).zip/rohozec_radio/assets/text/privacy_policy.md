**Zásady ochrany soukromí**

Aplikaci Radio Rohozec vytvořil Pivovar Rohozec jako bezplatnou aplikaci. Tato SLUŽBA je poskytována Pivovarem Rohozec bez nákladů a je určena k použití jak je.
Tato stránka je používána k informování návštěvníků o zásadách ohledně sběru, použití a zveřejňování osobních informací, pokud se někdo rozhodne využít mou službu.

Pokud se rozhodnete využívat službu, pak souhlasíte se sběrem a použitím informací v souvislosti s touto politikou. Nebudeme sdílet vaše informace s nikým, kromě případů popsaných v této politice ochrany soukromí.

Pojmy použité v této politice ochrany soukromí mají stejný význam jako v našich Smluvních podmínkách, které jsou přístupné na Radio Rohozec, pokud nejsou v této politice ochrany soukromí jinak definovány.

**Sběr a použití informací**

Pro lepší zážitek při použití naší služby můžeme vyžadovat, abyste nám poskytli určité osobní identifikační informace, včetně, ale nejen těchto: Žádné.

Aplikace využívá služby třetích stran, které mohou sbírat informace používané k vaší identifikaci.

Odkaz na zásady ochrany soukromí poskytovatelů služeb třetích stran použitých aplikací

**Google Play Services Facebook Log Data**

Chceme vás informovat, že kdykoli používáte službu, v případě chyby v aplikaci sbíráme data a informace (prostřednictvím produktů třetích stran) na vašem telefonu nazývané Log Data. Tato data mohou zahrnovat informace jako je vaše IP adresa, název zařízení, verze operačního systému, konfigurace aplikace při použití mé služby, čas a datum vašeho použití služby a další statistiky.

**Cookies**

Cookies jsou soubory s malým množstvím dat, které jsou běžně používány jako anonymní jedinečné identifikátory. Tyto jsou odesílány do vašeho prohlížeče z webových stránek, které navštěvujete, a jsou uloženy v interní paměti vašeho zařízení.

Tato služba nijak explicitně nevyužívá "cookies". Nicméně aplikace může využívat kód a knihovny třetích stran, které používají "cookies" k sběru informací a zlepšování svých služeb. Máte možnost buď přijmout nebo odmítnout tyto cookies a vědět, kdy je cookie odesláno na vaše zařízení. Pokud se rozhodnete odmítnout naše cookies, možná nebudete moci využívat některé části této služby.
Poskytovatelé služeb

Můžeme využívat společnosti a jednotlivce třetích stran z následujících důvodů:

Zjednodušení naší služby; Poskytnutí služby za nás; Poskytnutí služeb souvisejících se službou; nebo Pomoc nám při analýze, jak je naše služba používána. Chci informovat uživatele této služby, že tyto třetí strany mají přístup k jejich osobním informacím. Důvodem je plnění úkolů přidělených jim za nás. Jsou však povinni nezveřejňovat ani nepoužívat informace pro jiný účel.
Bezpečnost

Oceňujeme vaši důvěru v poskytování vašich osobních údajů, a proto se snažíme používat obchodně přijatelné prostředky k jeho ochraně. Ale pamatujte, že žádný způsob přenosu přes internet nebo metoda elektronického ukládání není 100% bezpečná a spolehlivá a nemohu zaručit jeho absolutní bezpečnost.
Odkazy na jiné stránky

Tato služba může obsahovat odkazy na jiné stránky. Pokud kliknete na odkaz třetí strany, budete přesměrováni na danou stránku. Upozorňuji, že tyto externí stránky nejsou provozovány mnou. Proto vám silně doporučuji, abyste si přečetli zásady ochrany soukromí těchto webových stránek. Nemáme kontrolu a nepřebíráme žádnou odpovědnost za obsah, zásady ochrany soukromí nebo praxe jakýchkoli webových stránek nebo služeb třetích stran.

**Ochrana soukromí dětí**

Tyto služby se nezabývají nikým mladším 13 let. Nevědomky nesbíráme osobní identifikační informace od dětí mladších 13 let. V případě, že zjistíme, že dítě mladší 13 let poskytlo své osobní údaje, okamžitě tyto informace z našich serverů odstraníme. Pokud jste rodič nebo zákonný zástupce a víte, že nám vaše dítě poskytlo své osobní údaje, kontaktujte nás, abych mohl podniknout nezbytné kroky.

**Změny této politiky ochrany soukromí**

Občas můžeme aktualizovat naši politiku ochrany soukromí. Proto vám doporučujeme pravidelně kontrolovat tuto stránku kvůli případným změnám. O jakýchkoli změnách vás budeme informovat zveřejněním nové politiky ochrany soukromí na této stránce.
Tato politika je účinná od 10.06.2023

**Kontaktujte nás**

Pokud máte jakékoliv otázky nebo návrhy ohledně mé politiky ochrany soukromí, neváhejte nás kontaktovat na adrese pivorohozec@pivorohozec.cz
