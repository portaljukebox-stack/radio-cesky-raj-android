Rádio Rohozec, domov jedinečných zvuků a chutí, kde se vášeň pro pivo spojuje s láskou k hudbě. Spojení malého pivovaru Rohozec a internetového rádia otevírá cestu do světa, kde se výroba piva stává nejen uměním, ale také zdrojem inspirace.

Rádio Rohozec není jen o hudbě. Je to most mezi vámi a naším pivovarem, místo, kde se kvasící umění setkává s melodickými tóny. Poslechněte si příběhy za jednotlivými pivy, zjistěte více o našem tradičním pivovarském procesu, a to vše při poslechu vámi oblíbených písní.

Na Rádiu Rohozec si můžete vychutnat širokou škálu hudebních žánrů - od rocku, popu, jazzu až po alternativní hudbu - stejně jako v našem pivovaru, kde nabízíme pestrou paletu piv od světlých až po tmavé, ať už máte rádi ležáky, polotmavé nebo speciály. Vítejte v našem světě, světě Rádia Rohozec.
